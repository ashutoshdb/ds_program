#include<stdio.h>

typedef struct node{
	int data;
	struct node *next;
} node;

node *front *rear;


void enqueue()
{
node *temp;
if(rear == NULL)
{

}

}
